-- ============================================================================
-- ECO-LOGIX V5 · DATA AWAL (MURNI DARI 0 — TANPA PENGIRIMAN DUMMY)
-- ============================================================================

INSERT IGNORE INTO `system_state` (
  `id`, `courier`, `progress`, `verified`, `otp`, `alpha`, `beta`,
  `selected_shipment_id`, `vendor_sharing`, `vendor_threshold`, `vendor_detour`,
  `vendor_area`, `vendor_volume`, `vendor_weight`, `vendor_decision`,
  `vendor_decided_at`, `vendor_sync_at`
) VALUES (
  1, 'a', 0, 0, '----', 70, 30, '', 1, 0.75, 2.00, 1, 1, 1, 'pending', NULL, 0
);
