-- ============================================================================
-- ECO-LOGIX V5 · STRUKTUR TABEL MYSQL (DIMULAI DARI 0 & 1 EMAIL = 1 ROLE)
-- ============================================================================

CREATE TABLE IF NOT EXISTS `users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(120) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `role_choice` ENUM('pengirim', 'kurir_a', 'kurir_b', 'vendor') NOT NULL DEFAULT 'pengirim',
  `role` ENUM('pengirim', 'kurir', 'vendor') NOT NULL DEFAULT 'pengirim',
  `courier_code` ENUM('a', 'b') DEFAULT NULL,
  `badge` VARCHAR(60) NOT NULL DEFAULT 'Pengirim',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `shipments` (
  `id` VARCHAR(24) NOT NULL,
  `user_id` INT UNSIGNED DEFAULT NULL,
  `sender` VARCHAR(80) NOT NULL,
  `city` VARCHAR(60) NOT NULL DEFAULT 'Kota Malang',
  `pickup_district` VARCHAR(60) NOT NULL,
  `pickup_address` VARCHAR(200) NOT NULL,
  `destination_district` VARCHAR(60) NOT NULL,
  `destination_address` VARCHAR(200) NOT NULL,
  `package_type` ENUM('Dokumen', 'Paket kecil', 'Paket sedang') NOT NULL DEFAULT 'Paket kecil',
  `quantity` INT UNSIGNED NOT NULL DEFAULT 1,
  `weight_kg` DECIMAL(8,2) NOT NULL DEFAULT 0.00,
  `dim_l` DECIMAL(8,2) NOT NULL DEFAULT 0.00,
  `dim_w` DECIMAL(8,2) NOT NULL DEFAULT 0.00,
  `dim_h` DECIMAL(8,2) NOT NULL DEFAULT 0.00,
  `volume_cm3` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `volume_liters` DECIMAL(8,2) NOT NULL DEFAULT 0.00,
  `notes` VARCHAR(255) NOT NULL DEFAULT '',
  `mode` ENUM('hijau', 'langsung') NOT NULL DEFAULT 'hijau',
  `stage` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `otp` CHAR(4) NOT NULL,
  `created_at` BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_shipments_created` (`created_at`),
  CONSTRAINT `fk_shipments_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `system_state` (
  `id` TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `courier` CHAR(1) NOT NULL DEFAULT 'a',
  `progress` INT UNSIGNED NOT NULL DEFAULT 0,
  `verified` TINYINT(1) NOT NULL DEFAULT 0,
  `otp` CHAR(4) NOT NULL DEFAULT '----',
  `alpha` INT UNSIGNED NOT NULL DEFAULT 70,
  `beta` INT UNSIGNED NOT NULL DEFAULT 30,
  `selected_shipment_id` VARCHAR(24) NOT NULL DEFAULT '',
  `vendor_sharing` TINYINT(1) NOT NULL DEFAULT 1,
  `vendor_threshold` DECIMAL(4,2) NOT NULL DEFAULT 0.75,
  `vendor_detour` DECIMAL(5,2) NOT NULL DEFAULT 2.00,
  `vendor_area` TINYINT(1) NOT NULL DEFAULT 1,
  `vendor_volume` TINYINT(1) NOT NULL DEFAULT 1,
  `vendor_weight` TINYINT(1) NOT NULL DEFAULT 1,
  `vendor_decision` ENUM('approved', 'rejected', 'pending') NOT NULL DEFAULT 'pending',
  `vendor_decided_at` BIGINT UNSIGNED DEFAULT NULL,
  `vendor_sync_at` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `vendor_history` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `decision` ENUM('approved', 'rejected') NOT NULL,
  `decided_at` BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_vendor_history_at` (`decided_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `handover_logs` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `shipment_id` VARCHAR(24) DEFAULT NULL,
  `otp` CHAR(4) NOT NULL,
  `log_text` VARCHAR(255) NOT NULL,
  `created_at` BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_handover_logs_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
