/**
 * 2. Modul Mesin Matematika Dinamis dari 0 (Haversine, δ, CMEM, Kapasitas Paket & Bagasi, Fungsi Objektif Z)
 */
'use strict';

function haversine(p, q) {
  const r = Math.PI / 180;
  const dLat = (q[0] - p[0]) * r;
  const dLon = (q[1] - p[1]) * r;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(p[0] * r) * Math.cos(q[0] * r) * Math.sin(dLon / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

function computeDelta(from, to) {
  const direct = haversine(from, to);
  const via = haversine(from, COORDS.hub) + haversine(COORDS.hub, to);
  return Math.max(0, Math.min(1, 1 - 0.5 * ((via - direct) / via)));
}

function getActiveShipment() {
  if (!state.shipments || state.shipments.length === 0) return null;
  return state.shipments.find(s => s.id === state.selectedShipmentId) || state.shipments[0] || null;
}

/**
 * Menghitung emisi CMEM murni berdasarkan berat muatan (kg).
 * Jika berat muatan = 0 (belum ada paket), seluruh emisi = 0,00 kg CO2.
 */
function computeCmemEmissions(totalWeightKg) {
  const w = Number(totalWeightKg) || 0;
  if (w <= 0) {
    return { totalLoadKg: 0, co2Separate: 0, co2Shared: 0, co2Saved: 0 };
  }
  const factorPerKm = 0.0645 + 0.0002 * w;
  const co2Separate = +(36 * factorPerKm).toFixed(2);
  const co2Shared = +(26 * factorPerKm).toFixed(2);
  const co2Saved = +(co2Separate - co2Shared).toFixed(2);
  return { totalLoadKg: w, co2Separate, co2Shared, co2Saved };
}

function computeVolumeMetrics(dimL, dimW, dimH, qty) {
  const l = Number(dimL) || 0;
  const w = Number(dimW) || 0;
  const h = Number(dimH) || 0;
  const q = Number(qty) || 0;
  if (l <= 0 || w <= 0 || h <= 0 || q <= 0) {
    return { l: 0, w: 0, h: 0, q: 0, unitCm3: 0, totalCm3: 0, totalLiters: 0 };
  }
  const unitCm3 = l * w * h;
  const totalCm3 = unitCm3 * q;
  const totalLiters = +(totalCm3 / 1000).toFixed(2);
  return { l, w, h, q, unitCm3, totalCm3, totalLiters };
}

/**
 * Menghitung seluruh metrik kapasitas, volume bagasi, berat, jarak, dan biaya
 * secara dinamis dari daftar pengiriman yang aktif (dimulai dari 0).
 */
function getCapacityMetrics() {
  const activeShips = (state.shipments || []).filter(s => s.stage < 5);
  const allShips = state.shipments || [];
  const targetShips = activeShips.length > 0 ? activeShips : allShips;

  const totalPackages = targetShips.reduce((sum, s) => sum + (Number(s.quantity) || 0), 0);
  const totalWeightKg = +(targetShips.reduce((sum, s) => sum + (Number(s.weightKg) || 0), 0)).toFixed(2);
  const totalBagasiLiters = +(targetShips.reduce((sum, s) => sum + (Number(s.volumeLiters) || 0), 0)).toFixed(2);

  const maxPackages = COURIERS.a.max; // 30
  const maxBagasiLiters = COURIERS.a.maxBagasiLiters; // 120.0 L

  const usedPackages = Math.min(maxPackages, totalPackages);
  const remPackages = Math.max(0, maxPackages - usedPackages);

  const usedBagasiLiters = +Math.min(maxBagasiLiters, totalBagasiLiters).toFixed(1);
  const remBagasiLiters = +Math.max(0, maxBagasiLiters - usedBagasiLiters).toFixed(1);

  const hasPackages = totalPackages > 0;
  const cmem = computeCmemEmissions(totalWeightKg);

  // Jarak & Biaya hanya muncul ketika ada pengiriman (jika 0 paket -> semua 0)
  const vmtBefore = hasPackages ? 36 : 0;
  const vmtAfter = hasPackages ? 26 : 0;
  const vmtSaved = hasPackages ? 10 : 0;
  const detourKm = hasPackages ? 2.0 : 0.0;
  const delta = hasPackages ? computeDelta(COORDS.a, COORDS.b) : 0.0;

  const costBeforePerPkg = hasPackages ? Math.round(90000 / totalPackages) : 0;
  const costAfterPerPkg = hasPackages ? Math.round(68600 / totalPackages) : 0;

  return {
    hasPackages,
    totalPackages,
    maxPackages,
    usedPackages,
    remPackages,
    maxBagasiLiters,
    usedBagasiLiters,
    remBagasiLiters,
    totalWeightKg,
    cmem,
    vmtBefore,
    vmtAfter,
    vmtSaved,
    detourKm,
    delta,
    costBeforePerPkg,
    costAfterPerPkg
  };
}

function getVendorBlocker() {
  const cap = getCapacityMetrics();
  if (!cap.hasPackages) {
    return 'Belum ada pengiriman masuk dari Pengirim (0 paket).';
  }
  const v = state.vendor;
  if (!v.sharing) return 'Fitur Load-Sharing dinonaktifkan pada pengaturan kebijakan.';
  if (cap.delta < v.threshold) return `Indeks kemiripan rute (δ = ${fmt(cap.delta, 2)}) di bawah ambang minimum (δ = ${fmt(v.threshold, 2)}).`;
  if (cap.detourKm > v.detour) return `Jarak memutar (2,0 km) melebihi batas maksimum (${fmt(v.detour, 1)} km).`;
  if (cap.totalPackages > cap.maxPackages) return `Jumlah paket (${cap.totalPackages}) melebihi kapasitas maksimal Kurir A (30 paket).`;
  if (cap.usedBagasiLiters > cap.maxBagasiLiters) return `Volume paket (${fmt(cap.usedBagasiLiters, 1)} L) melebihi kapasitas bagasi Kurir A (120,0 L).`;
  return '';
}

function isLoadSharingActive() {
  const cap = getCapacityMetrics();
  if (!cap.hasPackages) return false;
  if (getVendorBlocker()) return false;
  return state.vendor.decision === 'approved';
}

function computeObjectiveScores(previewWeightKg = null) {
  const activeShip = getActiveShipment();
  const w = previewWeightKg !== null
    ? (Number(previewWeightKg) || 0)
    : (activeShip ? (Number(activeShip.weightKg) || 0) : 0);

  const alpha = state.alpha / 100;
  const beta = state.beta / 100;

  if (w <= 0) {
    return { alpha, beta, fFuelDirect: 0, fFuelHub: 0, nStopDirect: 0, nStopHub: 0, zDirect: 0, zHub: 0, hubWins: false, hasInput: false };
  }

  const weightAdjustment = +((w * 0.12)).toFixed(2);
  const fFuelDirect = +(7.5 + weightAdjustment).toFixed(2);
  const fFuelHub = +(4.6 + weightAdjustment * 0.7).toFixed(2);
  const nStopDirect = 3;
  const nStopHub = 5;

  const zDirect = alpha * fFuelDirect + beta * nStopDirect;
  const zHub = alpha * fFuelHub + beta * nStopHub;
  return { alpha, beta, fFuelDirect, fFuelHub, nStopDirect, nStopHub, zDirect, zHub, hubWins: zHub <= zDirect, hasInput: true };
}
