/**
 * 7. Modul Render Antarmuka Vendor 3PL (Dinamis dari 0 & Terintegrasi ke Pengirim + Kurir)
 */
'use strict';

function renderVendor(collab, activeShip, cap) {
  const v = state.vendor;
  const blocker = getVendorBlocker();
  const used = cap.usedPackages;
  const rem = cap.remPackages;
  const load = Math.round((used / cap.maxPackages) * 100);
  const co0 = cap.cmem.co2Separate;
  const co1 = cap.cmem.co2Shared;
  const c0 = cap.costBeforePerPkg;
  const c1 = cap.costAfterPerPkg;

  const statusText = !cap.hasPackages
    ? 'Menunggu Pengiriman Masuk'
    : collab
      ? 'Kolaborasi Aktif (Disetujui)'
      : v.decision === 'rejected'
        ? 'Ditolak (Rute Langsung)'
        : v.decision === 'pending'
          ? 'Menunggu Keputusan Vendor'
          : 'Menunggu Syarat Kebijakan';

  $('v-st-badge').textContent = statusText;
  $('v-st-badge').className = 'text-xs sm:text-sm font-bold px-3.5 py-1 rounded-full ' + (collab ? 'bg-[#153d32] text-white' : 'bg-amber-200 text-amber-900');
  $('v-rq-val').textContent = statusText;

  $('v-m-load').textContent = cap.hasPackages ? `0% → ${load}%` : '0% → 0%';
  $('v-m-load2').textContent = `${load}% (${used}/${cap.maxPackages} paket · Sisa ${rem} paket)`;
  $('v-m-vmt').textContent = `${cap.vmtBefore} → ${cap.vmtAfter} km`;
  $('v-m-vmt2').textContent = !cap.hasPackages
    ? 'Belum ada pengiriman aktif'
    : collab
      ? '26 km gabungan (Kurir A 20 km + Kurir B 6 km)'
      : '36 km terpisah (18 km + 18 km)';
  $('v-m-co2').textContent = `${fmt(co0, 2)} → ${fmt(co1, 2)} kg`;
  $('v-m-co22').textContent = `${fmt(collab ? co1 : co0, 2)} kg CO₂ (Muatan ${fmt(cap.totalWeightKg, 1)} kg)`;
  $('v-m-cost').textContent = `${rp(c0)} → ${rp(c1)}`;
  $('v-m-cost2').textContent = `${rp(collab ? c1 : c0)} per paket`;

  // Fleet
  $('v-a-d').textContent = `${used} dari ${cap.maxPackages} paket · ${load}% (Sisa ${rem} paket)`;
  $('v-a-f').style.width = `${load}%`;
  $('v-a-pb').setAttribute('aria-valuenow', String(load));
  $('v-a-pill').textContent = cap.hasPackages ? 'Beroperasi' : 'Siaga';
  $('v-a-pill').className = 'text-xs font-bold px-3 py-1 rounded-full ' + (cap.hasPackages ? 'bg-[#e7f1d8] text-[#153d32]' : 'bg-gray-100 text-gray-700');
  $('v-a-r').textContent = `V_rem = V_max − V_isi = ${cap.maxPackages} − ${used} = ${rem} paket`;
  $('v-a-bagasi').textContent = `Bagasi: ${fmt(cap.usedBagasiLiters, 1)} / ${fmt(cap.maxBagasiLiters, 1)} L (Sisa ${fmt(cap.remBagasiLiters, 1)} L) · Berat muatan: ${fmt(cap.totalWeightKg, 1)} kg`;

  $('v-b-d').textContent = cap.hasPackages
    ? `Menyerahkan ${used} paket di Hub Merjosari · Rute 18 → 6 km`
    : '0 paket diserahkan di Hub Merjosari';
  $('v-b-f').style.width = `${load}%`;

  // Controls & Incoming Request Card
  $('v-sharing').checked = v.sharing;
  $('v-area').checked = v.area;
  $('v-volume').checked = v.volume;
  $('v-weight').checked = v.weight;
  if (document.activeElement !== $('v-threshold')) $('v-threshold').value = v.threshold;
  if (document.activeElement !== $('v-detour')) $('v-detour').value = v.detour;
  $('v-th-o').textContent = `δ = ${fmt(v.threshold, 2)}`;

  $('v-req-title').textContent = activeShip ? `Resi ${activeShip.id} (${activeShip.sender})` : 'Belum Ada Pengiriman';
  $('v-req-pkgs').textContent = `${used} paket`;
  $('v-req-wv').textContent = `${fmt(cap.totalWeightKg, 1)} kg · ${fmt(cap.usedBagasiLiters, 1)} L`;
  $('v-req-delta').innerHTML = `<span class="math-var">δ</span> = ${fmt(cap.delta, 2)}`;
  $('v-req-detour').textContent = `${fmt(cap.detourKm, 1)} km`;
  $('v-req-rem').textContent = `${rem} paket (${used}/30 terisi)`;
  $('v-req-co2-save').textContent = fmt(cap.cmem.co2Saved, 2);

  $('v-ok-btn').disabled = !!blocker;
  $('v-no-btn').disabled = !cap.hasPackages;
  $('v-why').hidden = !blocker;
  $('v-why').textContent = blocker;

  // Report Table
  $('v-tb').innerHTML = `
    <tr><th class="py-2 px-2">Jarak Gabungan (VMT)</th><td class="py-2 px-2">${cap.vmtBefore} km</td><td class="py-2 px-2 font-bold text-[#287044]">${cap.vmtAfter} km</td></tr>
    <tr><th class="py-2 px-2">Kapasitas Paket (V_rem)</th><td class="py-2 px-2">0 / 30 (Sisa 30)</td><td class="py-2 px-2 font-bold text-[#287044]">${used} / 30 (Sisa ${rem})</td></tr>
    <tr><th class="py-2 px-2">Volume Bagasi</th><td class="py-2 px-2">0,0 / 120,0 L</td><td class="py-2 px-2 font-bold text-[#287044]">${fmt(cap.usedBagasiLiters, 1)} / 120,0 L (Sisa ${fmt(cap.remBagasiLiters, 1)} L)</td></tr>
    <tr><th class="py-2 px-2">Emisi CO₂ (${fmt(cap.totalWeightKg, 1)} kg)</th><td class="py-2 px-2">${fmt(co0, 2)} kg</td><td class="py-2 px-2 font-bold text-[#287044]">${fmt(co1, 2)} kg</td></tr>
    <tr><th class="py-2 px-2">Biaya per Paket</th><td class="py-2 px-2">${rp(c0)}</td><td class="py-2 px-2 font-bold text-[#287044]">${rp(c1)}</td></tr>
  `;

  $('v-cost-share-text').textContent = !cap.hasPackages
    ? 'Belum ada pengiriman aktif (Rp 0).'
    : `Total ${used} paket aktif. Biaya gabungan Rp 68.600 dibagi rata menjadi Rp 34.300 per vendor (${rp(c1)}/paket), lebih hemat dibandingkan biaya mandiri Rp 45.000 per vendor (${rp(c0)}/paket).`;

  const tStr = collab && v.decidedAt ? wib(v.decidedAt) : '-';
  $('v-h1').textContent = `Kilat Raya → Hub Merjosari: ${!cap.hasPackages ? '-' : collab ? 'Disetujui (' + tStr + ')' : 'Menunggu'}`;
  $('v-h2').textContent = `Hub Merjosari → Eco Hemat: ${!cap.hasPackages ? '-' : state.verified ? 'Terverifikasi OTP' : collab ? 'Menunggu OTP Kurir' : 'Nonaktif'}`;
  $('v-h-otp').textContent = state.logs.length
    ? state.logs[state.logs.length - 1]
    : `OTP Aktif: ${activeShip ? activeShip.otp : '----'}`;

  $('v-hist').innerHTML = v.history.length
    ? v.history.slice().reverse().map(h => `<li>${wib(h.at)} · <strong>${h.d === 'approved' ? 'Disetujui' : 'Ditolak'}</strong></li>`).join('')
    : '<li>Belum ada keputusan (0 riwayat).</li>';
}
