/**
 * 4. Modul Peta Leaflet Interaktif
 */
'use strict';

let dashMap = null, routeMap = null, separateLayers = null, sharedLayer = null, simMarker = null, simPolyline = null;
let mapsInitialized = false;

function ensureMapsInitialized() {
  if (mapsInitialized) return;
  if (typeof window.L === 'undefined') {
    ['k-dash-map', 'k-route-map'].forEach(id => {
      const el = $(id);
      if (el) el.innerHTML = '<div class="h-full grid place-items-center p-4 text-center text-xs text-[#5e7268]">Peta membutuhkan koneksi internet.</div>';
    });
    return;
  }
  mapsInitialized = true;
  dashMap = L.map('k-dash-map', { scrollWheelZoom: false }).setView([-7.944, 112.606], 13);
  dashMap.attributionControl.setPrefix(false);
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; OpenStreetMap'
  }).addTo(dashMap);

  separateLayers = L.layerGroup([
    L.polyline(DIRECT_POINTS_A, { color: '#7c8781', weight: 4, dashArray: '6 7', opacity: 0.85 }),
    L.polyline(DIRECT_POINTS_B, { color: '#7c8781', weight: 4, dashArray: '6 7', opacity: 0.85 })
  ]).addTo(dashMap);

  sharedLayer = L.polyline(SHARED_POINTS, { color: '#247c48', weight: 5, opacity: 0.95 }).addTo(dashMap);
  L.circleMarker(COORDS.hub, { radius: 9, color: '#153d32', fillColor: '#b8e071', fillOpacity: 1, weight: 3 }).addTo(dashMap).bindPopup('<b>Hub Kel. Merjosari</b>');
  L.circleMarker(COORDS.a, { radius: 7, color: '#153d32', fillColor: '#ffffff', fillOpacity: 1, weight: 2.5 }).addTo(dashMap).bindPopup('<b>Kurir A · Eco Hemat</b>');
  L.circleMarker(COORDS.b, { radius: 7, color: '#153d32', fillColor: '#ffffff', fillOpacity: 1, weight: 2.5 }).addTo(dashMap).bindPopup('<b>Kurir B · Kilat Raya</b>');
  dashMap.fitBounds(L.latLngBounds([...DIRECT_POINTS_A, ...DIRECT_POINTS_B, COORDS.hub]).pad(0.14));

  routeMap = L.map('k-route-map', { scrollWheelZoom: false }).setView([-7.944, 112.606], 13);
  routeMap.attributionControl.setPrefix(false);
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; OpenStreetMap'
  }).addTo(routeMap);

  simPolyline = L.polyline(SHARED_POINTS, { color: '#247c48', weight: 5 }).addTo(routeMap);
  L.circleMarker(COORDS.hub, { radius: 8, color: '#153d32', fillColor: '#b8e071', fillOpacity: 1, weight: 2.5 }).addTo(routeMap).bindPopup('Hub Kel. Merjosari');
  simMarker = L.circleMarker(COORDS.a, { radius: 10, color: '#ffffff', fillColor: '#153d32', fillOpacity: 1, weight: 3 }).addTo(routeMap).bindPopup('Kurir');
  routeMap.fitBounds(L.latLngBounds(SHARED_POINTS).pad(0.18));
}

function getActiveRoutePoints() {
  const collab = isLoadSharingActive();
  if (!collab) {
    return state.courier === 'a' ? DIRECT_POINTS_A : DIRECT_POINTS_B;
  }
  return state.courier === 'a' ? SHARED_POINTS : [...SHARED_POINTS].reverse();
}
