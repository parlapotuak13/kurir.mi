/**
 * 1. Modul State Global Eco-LogiX (Semua Data Dimulai Murni dari 0)
 */
'use strict';

const $ = id => document.getElementById(id);
const DB_KEY = 'ecologix_zero_db_v5';
const STAGES = ['Diterima', 'Pengambilan', 'Transit Hub', 'Serah terima', 'Pengantaran', 'Selesai'];

const COORDS = {
  hub: [-7.9448, 112.6024],
  a: [-7.9521, 112.6160],
  b: [-7.9345, 112.6107]
};

const SHARED_POINTS = [
  COORDS.a,
  [-7.9494, 112.6101],
  COORDS.hub,
  [-7.9416, 112.5984],
  [-7.9370, 112.6050],
  COORDS.b
];

const DIRECT_POINTS_A = [COORDS.a, [-7.9480, 112.6200], [-7.9390, 112.6190], COORDS.b];
const DIRECT_POINTS_B = [COORDS.b, [-7.9309, 112.6040], [-7.9372, 112.5920], [-7.9480, 112.5980], COORDS.a];

const COURIERS = {
  a: { name: 'Kurir A · Eco Hemat', vendor: 'Eco Hemat', point: COORDS.a, max: 30, maxBagasiLiters: 120.0 },
  b: { name: 'Kurir B · Kilat Raya', vendor: 'Kilat Raya', point: COORDS.b, max: 30, maxBagasiLiters: 120.0 }
};

const ROLE_MAP = {
  pengirim: { role: 'pengirim', courierCode: null, badge: 'Pengirim' },
  kurir_a:  { role: 'kurir',    courierCode: 'a',  badge: 'Kurir · Eco Hemat' },
  kurir_b:  { role: 'kurir',    courierCode: 'b',  badge: 'Kurir · Kilat Raya' },
  vendor:   { role: 'vendor',   courierCode: null, badge: 'Vendor 3PL' }
};

const fmt = (n, d = 2) => Number(n || 0).toLocaleString('id-ID', { minimumFractionDigits: d, maximumFractionDigits: d });
const rp = n => 'Rp ' + Math.round(Number(n || 0)).toLocaleString('id-ID');
const timeFmt = new Intl.DateTimeFormat('id-ID', { timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit', hour12: false });
const wib = d => timeFmt.format(d ? new Date(d) : new Date()).replace('.', ':') + ' WIB';

function randomOtp() {
  try {
    const arr = new Uint32Array(1);
    crypto.getRandomValues(arr);
    return String(1000 + (arr[0] % 9000));
  } catch (e) {
    return String(Math.floor(1000 + Math.random() * 9000));
  }
}

/**
 * State awal benar-benar dari 0 (0 pengiriman, 0 paket, 0 log, 0 riwayat)
 */
function defaultState() {
  const now = Date.now();
  return {
    isLoggedIn: false,
    role: 'pengirim',
    currentUser: null,
    accounts: [],
    kTab: 'dashboard',
    pTab: 'create',
    vTab: 'dashboard',
    courier: 'a',
    progress: 0,
    running: false,
    verified: false,
    otp: '----',
    alpha: 70,
    beta: 30,
    logs: [],
    vendor: {
      sharing: true,
      threshold: 0.75,
      detour: 2.0,
      area: true,
      volume: true,
      weight: true,
      decision: 'pending',
      decidedAt: null,
      syncAt: now,
      history: []
    },
    shipments: [],
    selectedShipmentId: ''
  };
}

let state = defaultState();
let simTimer = null;
