/**
 * 3. Modul Klien Database & API (Sinkronisasi MySQL + Penyimpanan Terpadu)
 */
'use strict';

const channel = typeof BroadcastChannel !== 'undefined' ? new BroadcastChannel('ecologix_zero_sync_v5') : null;

function applyServerState(srv) {
  if (!srv || typeof srv !== 'object') return;
  state = {
    ...state,
    ...srv,
    vendor: { ...state.vendor, ...(srv.vendor || {}) },
    shipments: Array.isArray(srv.shipments) ? srv.shipments : state.shipments,
    accounts: Array.isArray(srv.accounts) ? srv.accounts : state.accounts,
    logs: Array.isArray(srv.logs) ? srv.logs : state.logs,
    running: state.running
  };
  try { localStorage.setItem(DB_KEY, JSON.stringify(state)); } catch (e) {}
}

if (typeof window.__SERVER_INITIAL_STATE__ !== 'undefined' && window.__SERVER_INITIAL_STATE__) {
  applyServerState(window.__SERVER_INITIAL_STATE__);
} else {
  try {
    const raw = localStorage.getItem(DB_KEY);
    if (raw) applyServerState(JSON.parse(raw));
  } catch (e) {}
}

let toastTimeout = null;
function showToast(msg) {
  const box = $('toast-box');
  if (!box) return;
  box.textContent = msg;
  box.hidden = false;
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => { box.hidden = true; }, 3200);
}

async function apiCall(action, payload = null) {
  try {
    const opts = payload !== null
      ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }
      : { method: 'GET' };
    const url = 'api.php?action=' + encodeURIComponent(action);
    const res = await fetch(url, opts);
    if (!res.ok && res.status === 404) return { ok: false, offline: true };
    const data = await res.json();
    if (data && data.ok && data.state) {
      applyServerState(data.state);
      if (channel) channel.postMessage(state);
    }
    return data;
  } catch (err) {
    return { ok: false, offline: true, error: err.message };
  }
}

function saveState(action = null, payload = null) {
  state.vendor.syncAt = Date.now();
  try {
    localStorage.setItem(DB_KEY, JSON.stringify(state));
    if (channel) channel.postMessage(state);
  } catch (e) {}
  if (action) {
    apiCall(action, payload || {});
  }
}
