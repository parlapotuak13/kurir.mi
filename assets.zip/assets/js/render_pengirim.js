/**
 * 5. Modul Render Antarmuka Pengirim (Dimulai dari 0 & Terintegrasi ke Vendor + Kurir)
 */
'use strict';

function renderPengirim(collab, activeShip, cap) {
  const formQty = Number($('p-qty').value) || 0;
  const formWeight = Number($('p-weight').value) || 0;
  const formL = Number($('p-dim-l').value) || 0;
  const formW = Number($('p-dim-w').value) || 0;
  const formH = Number($('p-dim-h').value) || 0;

  const volPreview = computeVolumeMetrics(formL, formW, formH, formQty);
  const totalWeightWithForm = +(cap.totalWeightKg + formWeight).toFixed(2);
  const cmemPreview = computeCmemEmissions(formWeight > 0 ? totalWeightWithForm : cap.totalWeightKg);
  const obj = computeObjectiveScores(formWeight > 0 ? formWeight : null);

  $('p-calc-vol').textContent = `${volPreview.totalCm3.toLocaleString('id-ID')} cm³ (${fmt(volPreview.totalLiters, 1)} L)`;
  $('p-calc-weight').textContent = `${fmt(formWeight, 1)} kg (Total Armada: ${fmt(cmemPreview.totalLoadKg, 1)} kg)`;
  $('p-calc-cmem').textContent = `${fmt(cmemPreview.co2Shared, 2)} kg CO₂`;

  $('p-alpha').value = state.alpha;
  $('p-beta').value = state.beta;
  $('p-alpha-val').textContent = fmt(obj.alpha, 2);
  $('p-beta-val').textContent = fmt(obj.beta, 2);
  $('p-direct-params').innerHTML = `<span class="math-var">f</span><sub>fuel</sub> = ${fmt(obj.fFuelDirect, 2)} · <span class="math-var">N</span><sub>stop</sub> = ${obj.nStopDirect}`;
  $('p-hub-params').innerHTML = `<span class="math-var">f</span><sub>fuel</sub> = ${fmt(obj.fFuelHub, 2)} · <span class="math-var">N</span><sub>stop</sub> = ${obj.nStopHub}`;
  $('p-direct-score').textContent = `Z = ${fmt(obj.zDirect, 2)}`;
  $('p-hub-score').textContent = `Z = ${fmt(obj.zHub, 2)}`;

  $('p-opt-direct').classList.toggle('winner', obj.hasInput && obj.zDirect < obj.zHub);
  $('p-opt-hub').classList.toggle('winner', obj.hasInput && obj.zHub <= obj.zDirect);
  $('p-best-route-text').textContent = !obj.hasInput
    ? 'Masukkan berat dan dimensi paket di atas untuk menghitung skor fungsi objektif Z.'
    : Math.abs(obj.zDirect - obj.zHub) < 1e-6
      ? 'Skor kedua rute setara.'
      : obj.hubWins
        ? `Rekomendasi: Rute via Hub (Z = ${fmt(obj.zHub, 2)})`
        : `Rekomendasi: Rute Langsung (Z = ${fmt(obj.zDirect, 2)})`;

  $('p-track-empty').hidden = !!activeShip;
  $('p-track-content').hidden = !activeShip;

  if (activeShip) {
    const isGreen = activeShip.mode === 'hijau';
    $('p-t-id').textContent = activeShip.id;
    $('p-t-mode-badge').textContent = isGreen ? 'Pengiriman Hijau' : 'Rute Langsung';
    $('p-t-mode-badge').className = 'text-xs font-bold px-3 py-1 rounded-full ' + (isGreen ? 'bg-[#e7f1d8] text-[#153d32]' : 'bg-gray-200 text-gray-800');
    $('p-t-status').textContent = STAGES[activeShip.stage];
    $('p-t-route').textContent = `${activeShip.sender} · ${activeShip.pickupDistrict} (${activeShip.pickupAddress}) → ${activeShip.destinationDistrict} (${activeShip.destinationAddress})`;
    $('p-t-specs').innerHTML = `
      <span>📦 ${activeShip.quantity} ${activeShip.packageType}</span>
      <span>⚖️ ${fmt(activeShip.weightKg, 1)} kg</span>
      <span>📐 ${activeShip.dimL}×${activeShip.dimW}×${activeShip.dimH} cm (${fmt(activeShip.volumeLiters, 1)} L)</span>
      <span>🌿 ${fmt(cap.cmem.co2Shared, 2)} kg CO₂</span>
    `;

    $('p-steps').innerHTML = STAGES.map((label, i) => `
      <li class="step-item ${i < activeShip.stage ? 'done' : i === activeShip.stage ? 'current' : ''}">
        <span class="font-semibold text-sm">${i < activeShip.stage ? '✓ ' : (i + 1) + '. '}${label}</span>
      </li>
    `).join('');

    $('p-advance-btn').disabled = activeShip.stage >= STAGES.length - 1;

    if (isGreen) {
      if (state.vendor.decision === 'pending') {
        $('p-story-text').textContent = 'Pengiriman Hijau telah masuk ke antrean. Menunggu persetujuan kolaborasi dari akun Vendor 3PL.';
        $('p-story-sub').textContent = `Estimasi penghematan setelah disetujui: ${fmt(cap.cmem.co2Saved, 2)} kg CO₂.`;
      } else if (collab) {
        $('p-story-text').textContent = 'Disetujui oleh Vendor 3PL! Paket dikonsolidasikan di Hub Kel. Merjosari dan diantar oleh armada kolaborasi.';
        $('p-story-sub').textContent = `Emisi: ${fmt(cap.cmem.co2Shared, 2)} kg CO₂ (Hemat ${fmt(cap.cmem.co2Saved, 2)} kg CO₂).`;
      } else {
        $('p-story-text').textContent = 'Kolaborasi ditolak atau tidak memenuhi ambang batas Vendor 3PL. Paket dialihkan ke Rute Langsung.';
        $('p-story-sub').textContent = `Emisi Rute Langsung: ${fmt(cap.cmem.co2Separate, 2)} kg CO₂.`;
      }
    } else {
      $('p-story-text').textContent = 'Paket dikirim menggunakan Rute Langsung tanpa transit di Hub Merjosari.';
      $('p-story-sub').textContent = `Emisi Rute Langsung: ${fmt(cap.cmem.co2Separate, 2)} kg CO₂.`;
    }

    const showHubLine = isGreen && collab;
    $('p-svg-title').textContent = showHubLine ? 'Rute Kolaborasi via Hub Merjosari' : 'Rute Langsung';
    $('p-svg-hub-line').style.display = showHubLine ? '' : 'none';
    $('p-svg-hub-node').style.display = showHubLine ? '' : 'none';
    $('p-svg-hub-label').textContent = showHubLine ? 'Hub Kel. Merjosari' : 'Rute Langsung';

    $('p-otp-display').textContent = activeShip.otp;
    const otpPill = $('p-otp-verified-pill');
    otpPill.textContent = state.verified ? 'Terverifikasi oleh Kurir' : 'Menunggu Verifikasi Kurir';
    otpPill.className = 'text-xs font-bold px-2.5 py-0.5 rounded-full ' + (state.verified ? 'bg-[#e7f1d8] text-[#153d32]' : 'bg-amber-100 text-amber-800');
  }

  $('p-h-empty').hidden = state.shipments.length > 0;
  const hList = $('p-h-list');
  hList.innerHTML = '';
  state.shipments.forEach(s => {
    const card = document.createElement('div');
    card.className = 'surface-card p-4 flex flex-wrap items-center justify-between gap-3 ' + (s.id === state.selectedShipmentId ? 'border-2 border-[#153d32]' : '');
    const info = document.createElement('div');
    info.innerHTML = `
      <div class="flex items-center gap-2">
        <strong class="text-base">${s.id}</strong>
        <span class="text-xs font-bold px-2.5 py-0.5 rounded-full bg-[#e7f1d8] text-[#153d32]">${STAGES[s.stage]}</span>
        <span class="text-xs text-[#5e7268]">${s.mode === 'hijau' ? 'Hijau' : 'Langsung'}</span>
      </div>
      <p class="text-xs text-[#5e7268] mt-1">${s.sender} · ${s.pickupDistrict} → ${s.destinationDistrict} · ${s.quantity} pkt · ${fmt(s.weightKg, 1)} kg · ${s.dimL}×${s.dimW}×${s.dimH} cm (${fmt(s.volumeLiters, 1)} L) · OTP: <strong>${s.otp}</strong></p>
    `;
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'btn-secondary text-xs';
    btn.textContent = s.id === state.selectedShipmentId ? 'Aktif' : 'Lacak';
    btn.addEventListener('click', () => {
      state.selectedShipmentId = s.id;
      state.otp = s.otp;
      saveState('select_shipment', { id: s.id });
      switchPengirimTab('track');
    });
    card.append(info, btn);
    hList.appendChild(card);
  });

  const greenList = state.shipments.filter(s => s.mode === 'hijau');
  const totalGreenPkgs = greenList.reduce((acc, s) => acc + (Number(s.quantity) || 0), 0);
  const totalGreenWeight = greenList.reduce((acc, s) => acc + (Number(s.weightKg) || 0), 0);
  const totalGreenVol = greenList.reduce((acc, s) => acc + (Number(s.volumeLiters) || 0), 0);
  const greenCmem = computeCmemEmissions(totalGreenWeight);

  $('p-i-co2').textContent = `${fmt(collab ? greenCmem.co2Saved : 0, 2)} kg`;
  $('p-i-count').textContent = String(greenList.length);
  $('p-i-pkgs').textContent = `${totalGreenPkgs} paket`;
  $('p-i-weight-vol').textContent = `${fmt(totalGreenWeight, 1)} kg · ${fmt(totalGreenVol, 1)} L`;
}
