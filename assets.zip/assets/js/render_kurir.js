/**
 * 6. Modul Render Antarmuka Kurir (Semua Angka Dinamis dari 0 Berdasarkan Kiriman Pengirim & Keputusan Vendor)
 */
'use strict';

function renderKurir(collab, activeShip, cap) {
  const loadPct = Math.round((cap.usedPackages / cap.maxPackages) * 100);

  if (!cap.hasPackages) {
    $('k-map-badge').textContent = 'Menunggu Pengiriman (0 Paket)';
    $('k-vmt-value').textContent = '0 → 0 km';
    $('k-vmt-sub').textContent = 'Hemat 0 km';
    $('k-carbon-value').textContent = '0,00 kg';
    $('k-carbon-sub').textContent = '0,00 → 0,00 kg';
    $('k-fill-tag').textContent = `0 / ${cap.maxPackages} paket (Sisa ${cap.maxPackages} paket)`;
    $('k-fill-value').textContent = '0%';
    $('k-fill-bar').style.width = '0%';
    $('k-bagasi-sub').textContent = `Bagasi: 0,0 / ${fmt(cap.maxBagasiLiters, 1)} L (Sisa ${fmt(cap.maxBagasiLiters, 1)} L) · Berat muatan: 0,0 kg`;

    $('k-tbl-vmt-before').textContent = '0 km';
    $('k-tbl-vmt-after').textContent = '0 km';
    $('k-tbl-co2-before').textContent = '0,00 kg CO₂';
    $('k-tbl-co2').textContent = '0,00 kg CO₂';
    $('k-tbl-cap-before').textContent = '0 / 30 paket (Sisa 30)';
    $('k-tbl-cap').textContent = '0 / 30 paket (Sisa 30)';
    $('k-tbl-cost-before').textContent = 'Rp 0';
    $('k-tbl-cost-after').textContent = 'Rp 0';
  } else {
    $('k-map-badge').textContent = collab ? 'Via Hub Merjosari (Kolaborasi Aktif)' : 'Rute Langsung';
    $('k-vmt-value').textContent = collab ? `${cap.vmtBefore} → ${cap.vmtAfter} km` : `${cap.vmtBefore} km`;
    $('k-vmt-sub').textContent = collab ? `Hemat ${cap.vmtSaved} km` : 'Rute tanpa kolaborasi';
    $('k-carbon-value').textContent = collab ? `${fmt(cap.cmem.co2Saved, 2)} kg` : '0,00 kg';
    $('k-carbon-sub').textContent = collab
      ? `${fmt(cap.cmem.co2Separate, 2)} → ${fmt(cap.cmem.co2Shared, 2)} kg`
      : `${fmt(cap.cmem.co2Separate, 2)} kg CO₂`;
    $('k-fill-tag').textContent = `${cap.usedPackages} / ${cap.maxPackages} paket (Sisa ${cap.remPackages} paket)`;
    $('k-fill-value').textContent = `${loadPct}%`;
    $('k-fill-bar').style.width = loadPct + '%';
    $('k-bagasi-sub').textContent = `Bagasi: ${fmt(cap.usedBagasiLiters, 1)} / ${fmt(cap.maxBagasiLiters, 1)} L (Sisa ${fmt(cap.remBagasiLiters, 1)} L) · Berat muatan: ${fmt(cap.totalWeightKg, 1)} kg`;

    $('k-tbl-vmt-before').textContent = `${cap.vmtBefore} km`;
    $('k-tbl-vmt-after').textContent = `${collab ? cap.vmtAfter : cap.vmtBefore} km`;
    $('k-tbl-co2-before').textContent = `${fmt(cap.cmem.co2Separate, 2)} kg CO₂`;
    $('k-tbl-co2').textContent = `${fmt(collab ? cap.cmem.co2Shared : cap.cmem.co2Separate, 2)} kg CO₂`;
    $('k-tbl-cap-before').textContent = `${cap.usedPackages} / 30 paket`;
    $('k-tbl-cap').textContent = `${cap.usedPackages} / 30 paket (Sisa ${cap.remPackages})`;
    $('k-tbl-cost-before').textContent = rp(cap.costBeforePerPkg);
    $('k-tbl-cost-after').textContent = rp(collab ? cap.costAfterPerPkg : cap.costBeforePerPkg);
  }

  const c = COURIERS[state.courier];
  $('k-courier-a').classList.toggle('active', state.courier === 'a');
  $('k-courier-b').classList.toggle('active', state.courier === 'b');
  $('k-courier-name').textContent = c.name;

  $('k-courier-pkg-badge').textContent = `${cap.usedPackages} / ${c.max} paket`;
  $('k-courier-detail').textContent = !cap.hasPackages
    ? 'Belum ada paket yang ditugaskan. Menunggu pengiriman baru dari Pengirim.'
    : state.courier === 'a'
      ? `Mengangkut ${cap.usedPackages} dari kapasitas ${c.max} paket (Sisa kapasitas V_rem = ${cap.remPackages} paket, sisa bagasi ${fmt(cap.remBagasiLiters, 1)} L).`
      : `Menyerahkan muatan kolaborasi (${cap.usedPackages} paket) di Hub Kel. Merjosari kepada Kurir A.`;

  const distToHub = cap.hasPackages ? haversine(c.point, COORDS.hub) : 0;
  $('k-match-distance').textContent = `${fmt(distToHub, 2)} km`;
  $('k-match-delta').textContent = fmt(cap.delta, 2);
  $('k-match-threshold').textContent = fmt(state.vendor.threshold, 2);
  $('k-match-capacity').textContent = `${cap.remPackages} paket`;
  $('k-match-cap-sub').textContent = `${cap.maxPackages} − ${cap.usedPackages} = ${cap.remPackages} paket`;
  $('k-match-bagasi').textContent = `${fmt(cap.remBagasiLiters, 1)} L`;
  $('k-match-bagasi-sub').textContent = `${fmt(cap.maxBagasiLiters, 0)} − ${fmt(cap.usedBagasiLiters, 1)} = ${fmt(cap.remBagasiLiters, 1)} L`;

  $('k-formula-delta').textContent = fmt(cap.delta, 2);
  $('k-formula-vrem').textContent = `${cap.maxPackages} − ${cap.usedPackages} = ${cap.remPackages} paket`;
  $('k-formula-bagasi').textContent = `${fmt(cap.maxBagasiLiters, 1)} − ${fmt(cap.usedBagasiLiters, 1)} = ${fmt(cap.remBagasiLiters, 1)} L`;
  $('k-cmem-supply-tag').textContent = `Berat Muatan: ${fmt(cap.totalWeightKg, 1)} kg`;

  const blocker = getVendorBlocker();
  const pill = $('k-vendor-policy-pill');
  if (!cap.hasPackages) {
    pill.textContent = 'Menunggu Pengiriman';
    pill.className = 'text-xs font-bold px-3 py-1 rounded-full bg-amber-100 text-amber-900';
    $('k-match-decision').textContent = 'Belum Ada Pengiriman Masuk (0 Paket)';
    $('k-match-decision').style.color = '#92400e';
  } else if (state.vendor.decision === 'pending') {
    pill.textContent = 'Menunggu Persetujuan Vendor';
    pill.className = 'text-xs font-bold px-3 py-1 rounded-full bg-amber-100 text-amber-900';
    $('k-match-decision').textContent = 'Menunggu Keputusan Vendor 3PL pada Tab Kolaborasi';
    $('k-match-decision').style.color = '#92400e';
  } else if (collab) {
    pill.textContent = 'Disetujui Vendor 3PL';
    pill.className = 'text-xs font-bold px-3 py-1 rounded-full bg-[#e7f1d8] text-[#153d32]';
    $('k-match-decision').textContent = 'Load-Sharing via Hub Merjosari';
    $('k-match-decision').style.color = '#287044';
  } else {
    pill.textContent = 'Rute Langsung';
    pill.className = 'text-xs font-bold px-3 py-1 rounded-full bg-amber-100 text-amber-900';
    $('k-match-decision').textContent = 'Rute Langsung (' + (blocker || 'Ditolak Vendor 3PL') + ')';
    $('k-match-decision').style.color = '#92400e';
  }

  // Navigasi Rute
  const pts = getActiveRoutePoints();
  $('k-sim-route-label').textContent = !cap.hasPackages
    ? 'Menunggu Pengiriman Aktif'
    : collab
      ? `Rute Kolaborasi via Hub Merjosari (${c.vendor})`
      : `Rute Langsung (${c.vendor})`;
  $('k-sim-pct').textContent = `${Math.round(state.progress)}%`;

  if (simPolyline && routeMap) {
    simPolyline.setLatLngs(pts);
    simPolyline.setStyle({ color: collab ? '#247c48' : '#64748b' });
  }
  if (simMarker && pts.length > 1) {
    const seg = (pts.length - 1) * (state.progress / 100);
    const idx = Math.min(pts.length - 2, Math.floor(seg));
    const t = Math.min(1, seg - idx);
    simMarker.setLatLng([
      pts[idx][0] + (pts[idx + 1][0] - pts[idx][0]) * t,
      pts[idx][1] + (pts[idx + 1][1] - pts[idx][1]) * t
    ]);
  }

  const step = Math.min(5, Math.floor(state.progress / 20));
  document.querySelectorAll('#k-step-list .step-item').forEach((el, i) => {
    el.classList.toggle('done', cap.hasPackages && i < step);
    el.classList.toggle('current', cap.hasPackages ? i === step : i === 0);
  });

  const totalCo2 = collab ? cap.cmem.co2Shared : cap.cmem.co2Separate;
  $('k-running-carbon').textContent = `${fmt((totalCo2 * state.progress) / 100, 2)} kg CO₂`;
  $('k-sim-btn').disabled = !cap.hasPackages;
  $('k-sim-step-btn').disabled = !cap.hasPackages;
  $('k-sim-btn').textContent = state.progress >= 100
    ? '↺ Ulangi'
    : state.running
      ? '⏸ Jeda'
      : state.progress > 0
        ? '▶ Lanjutkan'
        : '▶ Mulai';

  // Hub Merjosari
  const atHubPkgs = (cap.hasPackages && state.progress >= 40 && state.progress < 80) ? cap.usedPackages : 0;
  $('k-hub-count').textContent = `${atHubPkgs} / ${cap.usedPackages} paket`;
  $('k-hub-user-ships').textContent = `${state.shipments.length} resi (${cap.totalPackages} pkt)`;
  $('k-hub-verify-status').textContent = !cap.hasPackages
    ? 'Belum Ada Paket'
    : state.verified
      ? 'Terverifikasi'
      : 'Menunggu OTP';
  $('k-hub-verify-status').className = 'brand text-xl font-bold mt-1 block ' + (state.verified ? 'text-[#287044]' : 'text-[#92400e]');

  const pkgList = $('k-package-list');
  pkgList.innerHTML = '';
  if (state.shipments.length === 0) {
    pkgList.innerHTML = '<p class="py-4 text-center text-xs text-[#5e7268]">Belum ada paket yang masuk (0 paket).</p>';
  } else {
    state.shipments.forEach(s => {
      const row = document.createElement('div');
      row.className = 'flex justify-between items-center gap-3 py-2.5 text-xs sm:text-sm bg-[#f5faed] px-3 rounded-lg my-1';
      const left = document.createElement('div');
      left.innerHTML = `<strong class="text-[#153d32]">${s.id} · ${s.sender}</strong> <span class="text-xs text-[#5e7268]">(${s.quantity} ${s.packageType} · ${fmt(s.weightKg, 1)} kg · ${s.dimL}×${s.dimW}×${s.dimH} cm = ${fmt(s.volumeLiters, 1)} L)</span>`;
      const right = document.createElement('span');
      right.className = 'font-bold text-[#287044]';
      right.textContent = STAGES[s.stage];
      row.append(left, right);
      pkgList.appendChild(row);
    });
  }

  // Verifikasi OTP
  $('k-qr-caption').textContent = `ECO-HUB · MERJOSARI · ${cap.usedPackages} PAKET`;
  $('k-demo-otp').textContent = activeShip ? activeShip.otp : '----';
  $('k-verified-count').textContent = `${state.verified ? cap.usedPackages : 0} / ${cap.usedPackages} paket`;
  $('k-verify-btn').disabled = !cap.hasPackages || state.verified;
  $('k-verify-btn').textContent = !cap.hasPackages
    ? 'Belum Ada Pengiriman'
    : state.verified
      ? 'Sudah Terverifikasi'
      : 'Verifikasi';
  $('k-log-list').innerHTML = state.logs.length
    ? state.logs.map(l => `<div class="py-1 border-b border-[#edf2e8]">✓ ${l}</div>`).join('')
    : '<p class="text-[#5e7268]">Belum ada riwayat verifikasi (0 log).</p>';
}
