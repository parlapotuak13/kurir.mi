<?php
/**
 * Modul Tampilan Utama: Peran Kurir
 */
?>
<div id="view-kurir" class="role-view" hidden>
  <?php require __DIR__ . '/tab_dashboard.php'; ?>
  <?php require __DIR__ . '/tab_tasks.php'; ?>
  <?php require __DIR__ . '/tab_route.php'; ?>
  <?php require __DIR__ . '/tab_hub.php'; ?>
  <?php require __DIR__ . '/tab_verify.php'; ?>
</div>
