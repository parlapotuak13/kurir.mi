<section id="k-panel-dashboard" class="k-panel">
  <div class="mb-4">
    <p class="eyebrow">OPERASI KURIR · LOWOKWARU</p>
    <h2 class="brand text-2xl font-bold mt-0.5">Dasbor Pengantaran</h2>
  </div>

  <div class="grid lg:grid-cols-[1.35fr_1fr] gap-4">
    <div class="surface-card p-4">
      <div class="flex flex-wrap items-center justify-between gap-2 mb-3">
        <h3 class="font-bold text-base">Peta Rute</h3>
        <span id="k-map-badge" class="text-xs font-semibold px-2.5 py-1 rounded-full bg-[#e7f1d8] text-[#153d32]">Menunggu Pengiriman</span>
      </div>
      <div id="k-dash-map" class="map-frame" role="img" aria-label="Peta rute pengiriman"></div>
      <div class="flex flex-wrap gap-4 mt-3 text-xs sm:text-sm">
        <label class="inline-flex items-center gap-2 cursor-pointer">
          <input id="k-toggle-separate" type="checkbox" checked class="w-4 h-4 accent-gray-600">
          <span>Rute terpisah</span>
        </label>
        <label class="inline-flex items-center gap-2 cursor-pointer">
          <input id="k-toggle-shared" type="checkbox" checked class="w-4 h-4 accent-green-700">
          <span>Rute via Hub</span>
        </label>
      </div>
    </div>

    <div class="grid grid-cols-2 gap-3">
      <div class="surface-card p-4 flex flex-col justify-between">
        <p class="text-xs font-semibold text-[#5e7268]">Jarak Tempuh (VMT)</p>
        <div>
          <div id="k-vmt-value" class="brand text-2xl sm:text-3xl font-bold text-[#153d32] mt-2">0 → 0 km</div>
          <p id="k-vmt-sub" class="text-xs text-[#2f7651] font-semibold mt-1">Hemat 0 km</p>
        </div>
      </div>
      <div class="surface-card p-4 flex flex-col justify-between">
        <p class="text-xs font-semibold text-[#5e7268]">Emisi CO₂ Dihemat</p>
        <div>
          <div id="k-carbon-value" class="brand text-2xl sm:text-3xl font-bold text-[#153d32] mt-2">0,00 kg</div>
          <p id="k-carbon-sub" class="text-xs text-[#2f7651] font-semibold mt-1">0,00 → 0,00 kg</p>
        </div>
      </div>
      <div class="surface-card p-4 col-span-2">
        <div class="flex items-center justify-between">
          <p class="text-xs font-semibold text-[#5e7268]">Keterisian Kendaraan</p>
          <span id="k-fill-tag" class="text-xs font-bold text-[#2f7651]">0 / 30 paket (Sisa 30 paket)</span>
        </div>
        <div id="k-fill-value" class="brand text-2xl sm:text-3xl font-bold text-[#153d32] mt-1">0%</div>
        <div class="h-2.5 bg-[#e6eee0] rounded-full mt-3 overflow-hidden">
          <div id="k-fill-bar" class="h-full bg-[#2f7651] rounded-full transition-all duration-500" style="width: 0%"></div>
        </div>
        <p id="k-bagasi-sub" class="text-xs text-[#5e7268] mt-2">Bagasi: 0,0 / 120,0 L (Sisa 120,0 L) · Berat muatan: 0,0 kg</p>
      </div>
    </div>
  </div>

  <div class="surface-card p-4 sm:p-5 mt-4 overflow-x-auto">
    <h3 class="font-bold text-base mb-3">Perbandingan Sebelum vs Sesudah Kolaborasi</h3>
    <table class="w-full text-sm text-left border-collapse">
      <thead>
        <tr class="border-b border-[#dbe4d5] text-[#5e7268]">
          <th class="py-2.5 px-2 font-semibold">Indikator</th>
          <th class="py-2.5 px-2 font-semibold">Sebelum</th>
          <th class="py-2.5 px-2 font-semibold text-[#287044]">Sesudah</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-[#edf2e8]">
        <tr>
          <td class="py-2.5 px-2 font-medium">Jarak Tempuh (VMT)</td>
          <td class="py-2.5 px-2" id="k-tbl-vmt-before">0 km</td>
          <td class="py-2.5 px-2 font-bold text-[#287044]" id="k-tbl-vmt-after">0 km</td>
        </tr>
        <tr>
          <td class="py-2.5 px-2 font-medium">Emisi CO₂ (CMEM)</td>
          <td class="py-2.5 px-2" id="k-tbl-co2-before">0,00 kg CO₂</td>
          <td class="py-2.5 px-2 font-bold text-[#287044]" id="k-tbl-co2">0,00 kg CO₂</td>
        </tr>
        <tr>
          <td class="py-2.5 px-2 font-medium">Kapasitas Paket (<span class="math-var">V</span><sub>rem</sub>)</td>
          <td class="py-2.5 px-2" id="k-tbl-cap-before">0 / 30 paket (Sisa 30)</td>
          <td class="py-2.5 px-2 font-bold text-[#287044]" id="k-tbl-cap">0 / 30 paket (Sisa 30)</td>
        </tr>
        <tr>
          <td class="py-2.5 px-2 font-medium">Biaya per Paket</td>
          <td class="py-2.5 px-2" id="k-tbl-cost-before">Rp 0</td>
          <td class="py-2.5 px-2 font-bold text-[#287044]" id="k-tbl-cost-after">Rp 0</td>
        </tr>
      </tbody>
    </table>
  </div>
</section>
