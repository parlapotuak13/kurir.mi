<section id="k-panel-route" class="k-panel" hidden>
  <div class="mb-4">
    <p class="eyebrow">PERJALANAN</p>
    <h2 class="brand text-2xl font-bold mt-0.5">Navigasi Rute</h2>
  </div>

  <div class="grid lg:grid-cols-[1.25fr_1fr] gap-4">
    <div class="surface-card p-4">
      <div class="flex items-center justify-between mb-2">
        <span id="k-sim-route-label" class="text-xs font-bold text-[#153d32]">Menunggu Pengiriman Aktif</span>
        <span id="k-sim-pct" class="text-xs font-bold px-2 py-0.5 rounded bg-[#e7f1d8] text-[#153d32]">0%</span>
      </div>
      <div id="k-route-map" class="map-frame" role="img" aria-label="Peta perjalanan kurir"></div>
      <div class="flex items-center justify-between flex-wrap gap-3 mt-4">
        <div class="flex items-center gap-2">
          <button type="button" id="k-sim-btn" class="btn-primary">▶ Mulai</button>
          <button type="button" id="k-sim-step-btn" class="btn-secondary">+1 Tahap</button>
        </div>
        <div class="text-right">
          <span class="text-xs text-[#5e7268] block">Emisi Berjalan</span>
          <strong id="k-running-carbon" class="text-base font-bold text-[#153d32]">0,00 kg CO₂</strong>
        </div>
      </div>
    </div>

    <div class="surface-card p-5">
      <h3 class="font-bold text-base mb-4">Tahap Perjalanan</h3>
      <ol id="k-step-list">
        <li class="step-item current"><span class="font-semibold text-sm">1. Diterima</span></li>
        <li class="step-item"><span class="font-semibold text-sm">2. Pengambilan</span></li>
        <li class="step-item"><span class="font-semibold text-sm">3. Transit Hub Merjosari</span></li>
        <li class="step-item"><span class="font-semibold text-sm">4. Serah Terima</span></li>
        <li class="step-item"><span class="font-semibold text-sm">5. Pengantaran</span></li>
        <li class="step-item"><span class="font-semibold text-sm">6. Selesai</span></li>
      </ol>
    </div>
  </div>
</section>
