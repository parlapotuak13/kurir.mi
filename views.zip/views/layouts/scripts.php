  <script>
    window.__SERVER_INITIAL_STATE__ = <?php echo $initialStateJson; ?>;
  </script>
  <script src="assets/js/state.js"></script>
  <script src="assets/js/math_engine.js"></script>
  <script src="assets/js/api_client.js"></script>
  <script src="assets/js/map_manager.js"></script>
  <script src="assets/js/render_pengirim.js"></script>
  <script src="assets/js/render_kurir.js"></script>
  <script src="assets/js/render_vendor.js"></script>
  <script src="assets/js/app.js"></script>
