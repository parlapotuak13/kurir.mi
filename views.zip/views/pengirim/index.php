<?php
/**
 * Modul Tampilan Utama: Peran Pengirim
 */
?>
<div id="view-pengirim" class="role-view" hidden>
  <?php require __DIR__ . '/tab_create.php'; ?>
  <?php require __DIR__ . '/tab_track.php'; ?>
  <?php require __DIR__ . '/tab_history.php'; ?>
  <?php require __DIR__ . '/tab_impact.php'; ?>
</div>
