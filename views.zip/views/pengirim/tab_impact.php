<section id="p-panel-impact" class="p-panel" hidden>
  <div class="mb-4">
    <p class="eyebrow">DAMPAK LINGKUNGAN</p>
    <h2 class="brand text-2xl font-bold mt-0.5">Penghematan Emisi CO₂</h2>
  </div>

  <div class="rounded-3xl p-6 bg-[#153d32] text-[#d8ec9c] shadow-lg">
    <p class="text-xs uppercase tracking-wider font-bold text-[#b8e071]">Total Emisi CO₂ Dihemat</p>
    <strong id="p-i-co2" class="brand text-4xl sm:text-5xl font-bold block mt-2">0,00 kg</strong>
    <div class="my-5 border-t border-white/20"></div>
    <div class="grid grid-cols-3 gap-4">
      <div>
        <p class="text-xs text-[#cbe0ce]">Pengiriman Hijau</p>
        <strong id="p-i-count" class="brand text-2xl font-bold block mt-0.5">0</strong>
      </div>
      <div>
        <p class="text-xs text-[#cbe0ce]">Jumlah Paket</p>
        <strong id="p-i-pkgs" class="brand text-2xl font-bold block mt-0.5">0 paket</strong>
      </div>
      <div>
        <p class="text-xs text-[#cbe0ce]">Berat &amp; Volume</p>
        <strong id="p-i-weight-vol" class="brand text-lg sm:text-xl font-bold block mt-0.5">0,0 kg · 0,0 L</strong>
      </div>
    </div>
  </div>
</section>
