<section id="p-panel-history" class="p-panel" hidden>
  <div class="mb-4">
    <p class="eyebrow">RIWAYAT</p>
    <h2 class="brand text-2xl font-bold mt-0.5">Daftar Pengiriman</h2>
  </div>
  <div id="p-h-empty" class="surface-card p-6 text-center text-sm text-[#5e7268]">Belum ada riwayat pengiriman (0 pengiriman).</div>
  <div id="p-h-list" class="space-y-3"></div>
</section>
