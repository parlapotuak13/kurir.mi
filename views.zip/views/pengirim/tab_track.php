<section id="p-panel-track" class="p-panel" hidden>
  <div class="mb-4">
    <p class="eyebrow">PELACAKAN</p>
    <h2 class="brand text-2xl font-bold mt-0.5">Lacak Pengiriman</h2>
  </div>

  <div id="p-track-empty" class="surface-card p-6 text-center text-sm text-[#5e7268]">
    Belum ada pengiriman aktif. Silakan buat pengiriman terlebih dahulu pada tab Buat.
  </div>

  <div id="p-track-content" hidden>
    <div class="surface-card p-5 mb-4">
      <div class="flex flex-wrap items-center justify-between gap-2">
        <div>
          <p class="eyebrow">NOMOR RESI</p>
          <strong id="p-t-id" class="brand text-2xl font-bold">-</strong>
        </div>
        <div class="flex items-center gap-2">
          <span id="p-t-mode-badge" class="text-xs font-bold px-3 py-1 rounded-full bg-[#e7f1d8] text-[#153d32]">-</span>
          <span id="p-t-status" class="text-xs font-bold px-3 py-1 rounded-full bg-[#153d32] text-white">-</span>
        </div>
      </div>
      <p id="p-t-route" class="text-xs sm:text-sm text-[#5e7268] mt-2"></p>
      <div id="p-t-specs" class="mt-3 pt-3 border-t border-[#edf2e8] flex flex-wrap gap-3 text-xs font-semibold text-[#153d32]"></div>
    </div>

    <div class="grid sm:grid-cols-2 gap-4">
      <div class="surface-card p-5">
        <h3 class="font-bold text-base mb-4">Tahap Pengiriman</h3>
        <ol id="p-steps"></ol>
        <button id="p-advance-btn" type="button" class="btn-primary w-full mt-3">Perbarui Status</button>
      </div>

      <div class="space-y-4">
        <div class="soft-card p-5">
          <p class="eyebrow">INFORMASI RUTE &amp; KOLABORASI</p>
          <p id="p-story-text" class="text-sm leading-relaxed mt-2 font-medium"></p>
          <p id="p-story-sub" class="text-xs text-[#5e7268] mt-2"></p>
        </div>

        <div id="p-handoff-card" class="surface-card p-5">
          <div class="flex items-center justify-between">
            <h3 class="font-bold text-base">Kode OTP Serah Terima</h3>
            <span id="p-otp-verified-pill" class="text-xs font-bold px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800">Menunggu Verifikasi</span>
          </div>
          <div id="p-otp-display" class="brand mt-3 text-3xl font-bold tracking-[0.25em] p-3 rounded-xl bg-[#f3f6ec] text-center text-[#153d32]">----</div>
        </div>
      </div>
    </div>

    <div class="surface-card p-5 mt-4">
      <h3 id="p-svg-title" class="font-bold text-base mb-2">Peta Skema Rute</h3>
      <svg viewBox="0 0 360 175" role="img" aria-label="Skema rute pengiriman" class="w-full rounded-xl bg-[#e9f1e1] border border-[#d5e2c8]">
        <polyline id="p-svg-direct-line" points="50,135 180,95 310,50" fill="none" stroke="#8b968f" stroke-width="3.5" stroke-dasharray="6 6"/>
        <polyline id="p-svg-hub-line" points="50,135 115,95 175,45 245,65 310,50" fill="none" stroke="#247c48" stroke-width="5" stroke-linejoin="round" stroke-linecap="round"/>
        <circle cx="50" cy="135" r="8" fill="#276946" stroke="#fff" stroke-width="2.5"/>
        <circle id="p-svg-hub-node" cx="175" cy="45" r="9" fill="#d97706" stroke="#fff" stroke-width="2.5"/>
        <circle cx="310" cy="50" r="8" fill="#153d32" stroke="#fff" stroke-width="2.5"/>
        <g font-size="11" font-weight="700" fill="#153d32">
          <text x="24" y="158">Titik Jemput</text>
          <text id="p-svg-hub-label" x="128" y="26">Hub Kel. Merjosari</text>
          <text x="248" y="78">Tujuan Akhir</text>
        </g>
      </svg>
    </div>
  </div>
</section>
