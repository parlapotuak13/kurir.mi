<?php
declare(strict_types=1);

require_once __DIR__ . '/ShipmentModel.php';
require_once __DIR__ . '/VendorModel.php';
require_once __DIR__ . '/HandoverModel.php';

class StateModel
{
    public static function getRow(PDO $pdo): ?array
    {
        $row = $pdo->query("SELECT * FROM `system_state` WHERE `id` = 1 LIMIT 1")->fetch();
        return $row ?: null;
    }

    public static function getFullState(PDO $pdo): array
    {
        $row       = self::getRow($pdo);
        $shipments = ShipmentModel::getAll($pdo);
        $history   = VendorModel::getHistory($pdo);
        $logs      = HandoverModel::getLogs($pdo);
        $user      = function_exists('getActiveSessionUser') ? getActiveSessionUser() : ($_SESSION['ecologix_user'] ?? null);

        return [
            'isLoggedIn'         => $user !== null,
            'currentUser'        => $user,
            'role'               => $user['role'] ?? 'pengirim',
            'courier'            => $row ? (string) $row['courier'] : 'a',
            'progress'           => $row ? (int) $row['progress'] : 0,
            'verified'           => $row ? ((int) $row['verified'] === 1) : false,
            'otp'                => $row ? (string) $row['otp'] : '----',
            'alpha'              => $row ? (int) $row['alpha'] : 70,
            'beta'               => $row ? (int) $row['beta'] : 30,
            'selectedShipmentId' => $row ? (string) $row['selected_shipment_id'] : ($shipments[0]['id'] ?? ''),
            'logs'               => $logs,
            'vendor'             => [
                'sharing'   => $row ? ((int) $row['vendor_sharing'] === 1) : true,
                'threshold' => $row ? (float) $row['vendor_threshold'] : 0.75,
                'detour'    => $row ? (float) $row['vendor_detour'] : 2.0,
                'area'      => $row ? ((int) $row['vendor_area'] === 1) : true,
                'volume'    => $row ? ((int) $row['vendor_volume'] === 1) : true,
                'weight'    => $row ? ((int) $row['vendor_weight'] === 1) : true,
                'decision'  => $row ? (string) $row['vendor_decision'] : 'pending',
                'decidedAt' => ($row && $row['vendor_decided_at'] !== null) ? (int) $row['vendor_decided_at'] : null,
                'syncAt'    => $row ? (int) $row['vendor_sync_at'] : (int) round(microtime(true) * 1000),
                'history'   => $history,
            ],
            'shipments'          => $shipments,
        ];
    }
}
