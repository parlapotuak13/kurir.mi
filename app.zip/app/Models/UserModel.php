<?php
declare(strict_types=1);

class UserModel
{
    public static function findByEmail(PDO $pdo, string $email): ?array
    {
        $stmt = $pdo->prepare("SELECT * FROM `users` WHERE `email` = ? LIMIT 1");
        $stmt->execute([$email]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function create(PDO $pdo, string $name, string $email, string $hash, string $roleChoice, string $role, ?string $courierCode, string $badge): int
    {
        $stmt = $pdo->prepare("
            INSERT INTO `users` (`name`, `email`, `password_hash`, `role_choice`, `role`, `courier_code`, `badge`)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$name, $email, $hash, $roleChoice, $role, $courierCode, $badge]);
        return (int) $pdo->lastInsertId();
    }
}
