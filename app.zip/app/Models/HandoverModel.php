<?php
declare(strict_types=1);

class HandoverModel
{
    public static function getLogs(PDO $pdo): array
    {
        $rows = $pdo->query("SELECT `log_text` FROM `handover_logs` ORDER BY `id` ASC LIMIT 30")->fetchAll();
        $logs = [];
        foreach ($rows as $l) {
            $logs[] = (string) $l['log_text'];
        }
        return $logs;
    }

    public static function addLog(PDO $pdo, string $shipmentId, string $otp, string $logText, int $createdAt): void
    {
        $stmt = $pdo->prepare("
            INSERT INTO `handover_logs` (`shipment_id`, `otp`, `log_text`, `created_at`)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([$shipmentId, $otp, $logText, $createdAt]);
    }
}
