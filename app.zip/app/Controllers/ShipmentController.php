<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/Models/ShipmentModel.php';
require_once dirname(__DIR__) . '/Models/HandoverModel.php';
require_once dirname(__DIR__) . '/Models/StateModel.php';

class ShipmentController
{
    public static function create(PDO $pdo, array $body, int $nowMs): array
    {
        $id = trim((string) ($body['id'] ?? ''));
        if ($id === '') {
            $id = 'ELX-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
        }
        $user      = function_exists('getActiveSessionUser') ? getActiveSessionUser() : ($_SESSION['ecologix_user'] ?? null);
        $userId    = isset($user['id']) ? (int) $user['id'] : null;
        $sender    = substr(trim((string) ($body['sender'] ?? 'Pengirim')), 0, 80);
        $city      = substr(trim((string) ($body['city'] ?? 'Kota Malang')), 0, 60);
        $pd        = substr(trim((string) ($body['pickupDistrict'] ?? 'Lowokwaru')), 0, 60);
        $pa        = substr(trim((string) ($body['pickupAddress'] ?? '')), 0, 200);
        $dd        = substr(trim((string) ($body['destinationDistrict'] ?? 'Lowokwaru')), 0, 60);
        $da        = substr(trim((string) ($body['destinationAddress'] ?? '')), 0, 200);
        $pt        = in_array($body['packageType'] ?? '', ['Dokumen', 'Paket kecil', 'Paket sedang'], true)
                     ? (string) $body['packageType'] : 'Paket kecil';
        $qty       = max(1, min(30, (int) ($body['quantity'] ?? 1)));
        $weightKg  = max(0.1, min(60.0, (float) ($body['weightKg'] ?? 1.0)));
        $dimL      = max(1.0, min(150.0, (float) ($body['dimL'] ?? 10.0)));
        $dimW      = max(1.0, min(150.0, (float) ($body['dimW'] ?? 10.0)));
        $dimH      = max(1.0, min(150.0, (float) ($body['dimH'] ?? 10.0)));
        $volCm3    = round($dimL * $dimW * $dimH * $qty, 2);
        $volLiters = round($volCm3 / 1000.0, 2);
        $notes     = substr(trim((string) ($body['notes'] ?? '')), 0, 255);
        $mode      = ($body['mode'] ?? 'hijau') === 'langsung' ? 'langsung' : 'hijau';
        $otp       = preg_match('/^\d{4}$/', (string) ($body['otp'] ?? ''))
                     ? (string) $body['otp'] : (string) random_int(1000, 9999);

        $pdo->beginTransaction();
        ShipmentModel::create($pdo, [
            'id'                   => $id,
            'user_id'              => $userId,
            'sender'               => $sender,
            'city'                 => $city,
            'pickup_district'      => $pd,
            'pickup_address'       => $pa,
            'destination_district' => $dd,
            'destination_address'  => $da,
            'package_type'         => $pt,
            'quantity'             => $qty,
            'weight_kg'            => $weightKg,
            'dim_l'                => $dimL,
            'dim_w'                => $dimW,
            'dim_h'                => $dimH,
            'volume_cm3'           => $volCm3,
            'volume_liters'        => $volLiters,
            'notes'                => $notes,
            'mode'                 => $mode,
            'otp'                  => $otp,
            'created_at'           => $nowMs,
        ]);

        if ($mode === 'hijau') {
            $upd = $pdo->prepare("
                UPDATE `system_state`
                SET `selected_shipment_id` = ?, `otp` = ?, `progress` = 0, `verified` = 0,
                    `vendor_decision` = 'pending', `vendor_decided_at` = NULL, `vendor_sync_at` = ?
                WHERE `id` = 1
            ");
            $upd->execute([$id, $otp, $nowMs]);
        } else {
            $upd = $pdo->prepare("
                UPDATE `system_state`
                SET `selected_shipment_id` = ?, `otp` = ?, `progress` = 0, `verified` = 0, `vendor_sync_at` = ?
                WHERE `id` = 1
            ");
            $upd->execute([$id, $otp, $nowMs]);
        }
        $pdo->commit();

        return ['ok' => true, 'state' => StateModel::getFullState($pdo)];
    }

    public static function select(PDO $pdo, array $body, int $nowMs): array
    {
        $id   = trim((string) ($body['id'] ?? ''));
        $ship = ShipmentModel::findById($pdo, $id);
        if ($ship) {
            $upd = $pdo->prepare("
                UPDATE `system_state`
                SET `selected_shipment_id` = ?, `otp` = ?, `progress` = ?, `vendor_sync_at` = ?
                WHERE `id` = 1
            ");
            $upd->execute([$ship['id'], $ship['otp'], ((int) $ship['stage']) * 20, $nowMs]);
        }
        return ['ok' => true, 'state' => StateModel::getFullState($pdo)];
    }

    public static function advance(PDO $pdo, array $body, int $nowMs): array
    {
        $id   = trim((string) ($body['id'] ?? ''));
        $ship = ShipmentModel::findById($pdo, $id);
        if ($ship) {
            $newStage = min(5, ((int) $ship['stage']) + 1);
            $newProg  = $newStage * 20;
            $pdo->beginTransaction();
            ShipmentModel::updateStage($pdo, $id, $newStage);

            $updSt = $pdo->prepare("UPDATE `system_state` SET `progress` = ?, `vendor_sync_at` = ? WHERE `id` = 1");
            $updSt->execute([$newProg, $nowMs]);
            $pdo->commit();
        }
        return ['ok' => true, 'state' => StateModel::getFullState($pdo)];
    }
}
