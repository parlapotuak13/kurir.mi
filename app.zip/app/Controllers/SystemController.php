<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/Models/StateModel.php';

class SystemController
{
    public static function updateObjectiveWeights(PDO $pdo, array $body, int $nowMs): array
    {
        $alpha = max(0, min(100, (int) ($body['alpha'] ?? 70)));
        $beta  = max(0, min(100, (int) ($body['beta'] ?? 30)));
        $upd = $pdo->prepare("UPDATE `system_state` SET `alpha` = ?, `beta` = ?, `vendor_sync_at` = ? WHERE `id` = 1");
        $upd->execute([$alpha, $beta, $nowMs]);
        return ['ok' => true, 'state' => StateModel::getFullState($pdo)];
    }

    public static function resetAll(PDO $pdo, int $nowMs): array
    {
        $pdo->beginTransaction();
        $pdo->exec("DELETE FROM `handover_logs`");
        $pdo->exec("DELETE FROM `vendor_history`");
        $pdo->exec("DELETE FROM `shipments`");

        $updSt = $pdo->prepare("
            UPDATE `system_state`
            SET `courier` = 'a', `progress` = 0, `verified` = 0, `otp` = '----',
                `alpha` = 70, `beta` = 30, `selected_shipment_id` = '',
                `vendor_sharing` = 1, `vendor_threshold` = 0.75, `vendor_detour` = 2.00,
                `vendor_area` = 1, `vendor_volume` = 1, `vendor_weight` = 1,
                `vendor_decision` = 'pending', `vendor_decided_at` = NULL, `vendor_sync_at` = ?
            WHERE `id` = 1
        ");
        $updSt->execute([$nowMs]);
        $pdo->commit();

        return ['ok' => true, 'state' => StateModel::getFullState($pdo)];
    }
}
