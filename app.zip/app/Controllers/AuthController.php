<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/Models/UserModel.php';
require_once dirname(__DIR__) . '/Models/StateModel.php';

class AuthController
{
    /**
     * Aturan Ketat:
     * 1. Saat Register: Jika email sudah ada di database -> tolak dengan pesan "Akun sudah ada, silahkan masuk"
     * 2. Saat Login:
     *    - Jika email belum ada -> "Akun belum terdaftar, silahkan daftar akun terlebih dahulu."
     *    - Jika kata sandi salah -> "Kata sandi salah."
     *    - Jika memilih role yang berbeda dari saat didaftarkan -> "Email ini terdaftar untuk peran [Badge]. 1 email hanya berlaku untuk 1 peran."
     */
    public static function handleLoginOrRegister(PDO $pdo, array $body, string $action, int $nowMs): array
    {
        $email      = strtolower(trim((string) ($body['email'] ?? '')));
        $pass       = (string) ($body['pass'] ?? '');
        $roleChoice = (string) ($body['roleChoice'] ?? 'pengirim');
        $inputName  = trim((string) ($body['name'] ?? ''));

        if ($email === '' || strlen($pass) < 4) {
            http_response_code(400);
            return ['ok' => false, 'error' => 'Email dan kata sandi (minimal 4 karakter) wajib diisi.'];
        }

        $roleMap = [
            'pengirim' => ['role' => 'pengirim', 'courierCode' => null, 'badge' => 'Pengirim'],
            'kurir_a'  => ['role' => 'kurir',    'courierCode' => 'a',  'badge' => 'Kurir · Eco Hemat'],
            'kurir_b'  => ['role' => 'kurir',    'courierCode' => 'b',  'badge' => 'Kurir · Kilat Raya'],
            'vendor'   => ['role' => 'vendor',   'courierCode' => null, 'badge' => 'Vendor 3PL'],
        ];
        if (!isset($roleMap[$roleChoice])) {
            $roleChoice = 'pengirim';
        }
        $rm = $roleMap[$roleChoice];

        $existing = UserModel::findByEmail($pdo, $email);

        if ($action === 'register') {
            if ($existing !== null) {
                http_response_code(409);
                return ['ok' => false, 'error' => 'Akun sudah ada, silahkan masuk'];
            }
            $displayName = $inputName !== '' ? $inputName : explode('@', $email)[0];
            $hash        = password_hash($pass, PASSWORD_BCRYPT);
            $userId      = UserModel::create($pdo, $displayName, $email, $hash, $roleChoice, $rm['role'], $rm['courierCode'], $rm['badge']);
            $userData    = [
                'id'          => $userId,
                'email'       => $email,
                'name'        => $displayName,
                'roleChoice'  => $roleChoice,
                'role'        => $rm['role'],
                'courierCode' => $rm['courierCode'],
                'badge'       => $rm['badge'],
            ];
        } else {
            // Mode Login
            if ($existing === null) {
                http_response_code(404);
                return ['ok' => false, 'error' => 'Akun belum terdaftar, silahkan daftar akun terlebih dahulu.'];
            }
            if (!password_verify($pass, (string) $existing['password_hash'])) {
                http_response_code(401);
                return ['ok' => false, 'error' => 'Kata sandi salah.'];
            }
            if (!empty($existing['role_choice']) && (string) $existing['role_choice'] !== $roleChoice) {
                http_response_code(403);
                return [
                    'ok'    => false,
                    'error' => 'Email ini terdaftar untuk peran ' . $existing['badge'] . '. 1 email hanya berlaku untuk 1 peran.',
                ];
            }
            $userData = [
                'id'          => (int) $existing['id'],
                'email'       => (string) $existing['email'],
                'name'        => (string) $existing['name'],
                'roleChoice'  => (string) $existing['role_choice'],
                'role'        => (string) $existing['role'],
                'courierCode' => $existing['courier_code'] !== null ? (string) $existing['courier_code'] : null,
                'badge'       => (string) $existing['badge'],
            ];
        }

        if ($userData['courierCode'] !== null) {
            $upd = $pdo->prepare("UPDATE `system_state` SET `courier` = ?, `vendor_sync_at` = ? WHERE `id` = 1");
            $upd->execute([$userData['courierCode'], $nowMs]);
        }

        if (function_exists('setActiveSessionUser')) {
            setActiveSessionUser($userData);
        } else {
            $_SESSION['ecologix_user'] = $userData;
        }

        return ['ok' => true, 'state' => StateModel::getFullState($pdo)];
    }

    public static function handleLogout(PDO $pdo): array
    {
        if (function_exists('setActiveSessionUser')) {
            setActiveSessionUser(null);
        } else {
            unset($_SESSION['ecologix_user']);
        }
        return ['ok' => true, 'state' => StateModel::getFullState($pdo)];
    }
}
