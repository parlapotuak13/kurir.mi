<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/Models/VendorModel.php';
require_once dirname(__DIR__) . '/Models/StateModel.php';

class VendorController
{
    public static function updateSettings(PDO $pdo, array $body, int $nowMs): array
    {
        $v         = $body['vendor'] ?? [];
        $sharing   = !empty($v['sharing']) ? 1 : 0;
        $threshold = max(0.50, min(0.95, (float) ($v['threshold'] ?? 0.75)));
        $detour    = max(0.0, min(20.0, (float) ($v['detour'] ?? 2.0)));
        $area      = !empty($v['area']) ? 1 : 0;
        $volume    = !empty($v['volume']) ? 1 : 0;
        $weight    = !empty($v['weight']) ? 1 : 0;
        $decision  = in_array($v['decision'] ?? '', ['approved', 'rejected', 'pending'], true)
                     ? (string) $v['decision'] : 'approved';
        $decidedAt = $decision === 'approved' ? $nowMs : null;

        $pdo->beginTransaction();
        $upd = $pdo->prepare("
            UPDATE `system_state`
            SET `vendor_sharing` = ?, `vendor_threshold` = ?, `vendor_detour` = ?,
                `vendor_area` = ?, `vendor_volume` = ?, `vendor_weight` = ?,
                `vendor_decision` = ?, `vendor_decided_at` = ?, `vendor_sync_at` = ?
            WHERE `id` = 1
        ");
        $upd->execute([$sharing, $threshold, $detour, $area, $volume, $weight, $decision, $decidedAt, $nowMs]);

        if (!empty($body['recordHistory']) && in_array($decision, ['approved', 'rejected'], true)) {
            VendorModel::addHistory($pdo, $decision, $nowMs);
        }
        $pdo->commit();

        return ['ok' => true, 'state' => StateModel::getFullState($pdo)];
    }
}
