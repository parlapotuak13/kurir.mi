<?php
declare(strict_types=1);

require_once __DIR__ . '/constants.php';
require_once dirname(__DIR__) . '/database/migrator.php';

define('DB_HOST', getenv('DB_HOST') ?: '127.0.0.1');
define('DB_PORT', getenv('DB_PORT') ?: '3306');
define('DB_NAME', getenv('DB_NAME') ?: 'ecologix');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') !== false ? getenv('DB_PASS') : '');
define('DB_SSL',  getenv('DB_SSL') ?: 'false');

function getActiveSessionUser(): ?array
{
    if (!empty($_SESSION['ecologix_user']) && is_array($_SESSION['ecologix_user'])) {
        return $_SESSION['ecologix_user'];
    }
    if (!empty($_COOKIE['ecologix_auth'])) {
        $decoded = json_decode((string) base64_decode((string) $_COOKIE['ecologix_auth'], true), true);
        if (is_array($decoded) && !empty($decoded['email']) && !empty($decoded['role'])) {
            $_SESSION['ecologix_user'] = $decoded;
            return $decoded;
        }
    }
    return null;
}

function setActiveSessionUser(?array $user): void
{
    if ($user === null) {
        unset($_SESSION['ecologix_user']);
        if (!headers_sent()) {
            setcookie('ecologix_auth', '', time() - 3600, '/', '', false, true);
        }
        return;
    }
    $_SESSION['ecologix_user'] = $user;
    if (!headers_sent()) {
        $encoded = base64_encode((string) json_encode($user, JSON_UNESCAPED_UNICODE));
        setcookie('ecologix_auth', $encoded, time() + 86400 * 7, '/', '', false, true);
    }
}

function getDbConnection(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::ATTR_TIMEOUT            => 4,
    ];

    if (strtolower((string) DB_SSL) === 'true' || strpos((string) DB_HOST, 'tidbcloud.com') !== false || strpos((string) DB_HOST, 'aivencloud.com') !== false) {
        $options[PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT] = false;
    }

    try {
        $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_PORT, DB_NAME);
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    } catch (PDOException $e) {
        $dsnNoDb = sprintf('mysql:host=%s;port=%s;charset=utf8mb4', DB_HOST, DB_PORT);
        $tempPdo = new PDO($dsnNoDb, DB_USER, DB_PASS, $options);
        $dbNameQuoted = '`' . str_replace('`', '``', DB_NAME) . '`';
        $tempPdo->exec("CREATE DATABASE IF NOT EXISTS {$dbNameQuoted} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $tempPdo = null;

        $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_PORT, DB_NAME);
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    }

    runDatabaseMigrator($pdo);
    return $pdo;
}
