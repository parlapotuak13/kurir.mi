<?php
declare(strict_types=1);

define('APP_NAME', 'Eco-LogiX');
define('APP_VERSION', '5.0.0');
define('DEFAULT_CITY', 'Kota Malang');
define('COURIER_MAX_PACKAGES', 30);
define('COURIER_MAX_BAGASI_LITERS', 120.0);
